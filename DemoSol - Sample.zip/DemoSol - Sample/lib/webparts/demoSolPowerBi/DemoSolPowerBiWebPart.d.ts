import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import './DemoSolPowerBiWebPart.module.scss';
export interface IPowerBiReportLoaderWebPartProps {
    workspaceId: string;
    reportId: string;
}
export default class PowerBiReportLoaderWebPart extends BaseClientSideWebPart<IPowerBiReportLoaderWebPartProps> {
    private workspaceOptions;
    private workspacesFetched;
    private fetchWorkspaceOptions;
    private reportOptions;
    private reportsFetched;
    private fetchReportOptions;
    render(): void;
    protected onPropertyPaneConfigurationStart(): void;
    protected onPropertyPaneFieldChanged(propertyPath: string, oldValue: any, newValue: any): void;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=DemoSolPowerBiWebPart.d.ts.map