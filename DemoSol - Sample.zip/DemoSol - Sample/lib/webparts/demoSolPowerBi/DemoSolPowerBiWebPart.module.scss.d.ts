declare const styles: {
    demoSolPowerBi: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=DemoSolPowerBiWebPart.module.scss.d.ts.map