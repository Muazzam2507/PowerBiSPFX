import { PowerBiWorkspace, PowerBiDashboard, PowerBiReport } from "./../models/PowerBiModels";
import { ServiceScope } from '@microsoft/sp-core-library';
export declare class PowerBiService {
    private static powerbiApiResourceId;
    private static workspacesUrl;
    private static adalAccessTokenStorageKey;
    static GetWorkspaces: (serviceScope: ServiceScope) => Promise<PowerBiWorkspace[]>;
    static GetReports: (serviceScope: ServiceScope, workspaceId: string) => Promise<PowerBiReport[]>;
    static GetReport: (serviceScope: ServiceScope, workspaceId: string, reportId: string) => Promise<PowerBiReport>;
    static GetDashboards: (serviceScope: ServiceScope, workspaceId: string) => Promise<PowerBiDashboard[]>;
    static GetDashboard: (serviceScope: ServiceScope, workspaceId: string, dashboardId: string) => Promise<PowerBiDashboard>;
}
//# sourceMappingURL=PowerBiService.d.ts.map