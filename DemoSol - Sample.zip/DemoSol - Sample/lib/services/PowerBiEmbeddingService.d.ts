import { PowerBiDashboard, PowerBiReport, PowerBiDataset } from "./../models/PowerBiModels";
export declare class PowerBiEmbeddingService {
    static reset(embedContainer: HTMLElement): void;
    static embedDashboard(dashboard: PowerBiDashboard, embedContainer: HTMLElement): void;
    static embedDashboardTiles(dashboard: PowerBiDashboard, embedContainer: HTMLElement): void;
    static embedReport(report: PowerBiReport, embedContainer: HTMLElement): void;
    static embedNewReport(dataset: PowerBiDataset, embedContainer: HTMLElement): void;
    static embedQnA(dataset: PowerBiDataset, embedContainer: HTMLElement): void;
}
//# sourceMappingURL=PowerBiEmbeddingService.d.ts.map