declare interface IDemoSolPowerBiWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  AppLocalEnvironmentSharePoint: string;
  AppLocalEnvironmentTeams: string;
  AppSharePointEnvironment: string;
  AppTeamsTabEnvironment: string;
}

declare module 'DemoSolPowerBiWebPartStrings' {
  const strings: IDemoSolPowerBiWebPartStrings;
  export = strings;
}
