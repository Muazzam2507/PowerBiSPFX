/* tslint:disable */
require("./DemoSolPowerBiWebPart.module.css");
const styles = {
  demoSolPowerBi: 'demoSolPowerBi_65fef784',
  teams: 'teams_65fef784',
  welcome: 'welcome_65fef784',
  welcomeImage: 'welcomeImage_65fef784',
  links: 'links_65fef784'
};

export default styles;
/* tslint:enable */