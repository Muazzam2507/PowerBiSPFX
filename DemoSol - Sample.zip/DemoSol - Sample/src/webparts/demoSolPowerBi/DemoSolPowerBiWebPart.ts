/*
import { Version } from '@microsoft/sp-core-library';
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { IReadonlyTheme } from '@microsoft/sp-component-base';
import { escape } from '@microsoft/sp-lodash-subset';

import styles from './DemoSolPowerBiWebPart.module.scss';
import * as strings from 'DemoSolPowerBiWebPartStrings';

export interface IDemoSolPowerBiWebPartProps {
  description: string;
}

export default class DemoSolPowerBiWebPart extends BaseClientSideWebPart<IDemoSolPowerBiWebPartProps> {

  private _isDarkTheme: boolean = false;
  private _environmentMessage: string = '';

  protected onInit(): Promise<void> {
    this._environmentMessage = this._getEnvironmentMessage();

    return super.onInit();
  }

  public render(): void {
    this.domElement.innerHTML = `
    <section class="${styles.demoSolPowerBi} ${!!this.context.sdks.microsoftTeams ? styles.teams : ''}">
      <div class="${styles.welcome}">
        <img alt="" src="${this._isDarkTheme ? require('./assets/welcome-dark.png') : require('./assets/welcome-light.png')}" class="${styles.welcomeImage}" />
        <h2>Well done, ${escape(this.context.pageContext.user.displayName)}!</h2>
        <div>${this._environmentMessage}</div>
        <div>Web part property value: <strong>${escape(this.properties.description)}</strong></div>
      </div>
      <div>
        <h3>Welcome to SharePoint Framework!</h3>
        <p>
        The SharePoint Framework (SPFx) is a extensibility model for Microsoft Viva, Microsoft Teams and SharePoint. It's the easiest way to extend Microsoft 365 with automatic Single Sign On, automatic hosting and industry standard tooling.
        </p>
        <h4>Learn more about SPFx development:</h4>
          <ul class="${styles.links}">
            <li><a href="https://aka.ms/spfx" target="_blank">SharePoint Framework Overview</a></li>
            <li><a href="https://aka.ms/spfx-yeoman-graph" target="_blank">Use Microsoft Graph in your solution</a></li>
            <li><a href="https://aka.ms/spfx-yeoman-teams" target="_blank">Build for Microsoft Teams using SharePoint Framework</a></li>
            <li><a href="https://aka.ms/spfx-yeoman-viva" target="_blank">Build for Microsoft Viva Connections using SharePoint Framework</a></li>
            <li><a href="https://aka.ms/spfx-yeoman-store" target="_blank">Publish SharePoint Framework applications to the marketplace</a></li>
            <li><a href="https://aka.ms/spfx-yeoman-api" target="_blank">SharePoint Framework API reference</a></li>
            <li><a href="https://aka.ms/m365pnp" target="_blank">Microsoft 365 Developer Community</a></li>
          </ul>
      </div>
    </section>`;
  }

  private _getEnvironmentMessage(): string {
    if (!!this.context.sdks.microsoftTeams) { // running in Teams
      return this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentTeams : strings.AppTeamsTabEnvironment;
    }

    return this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentSharePoint : strings.AppSharePointEnvironment;
  }

  protected onThemeChanged(currentTheme: IReadonlyTheme | undefined): void {
    if (!currentTheme) {
      return;
    }

    this._isDarkTheme = !!currentTheme.isInverted;
    const {
      semanticColors
    } = currentTheme;
    this.domElement.style.setProperty('--bodyText', semanticColors.bodyText);
    this.domElement.style.setProperty('--link', semanticColors.link);
    this.domElement.style.setProperty('--linkHovered', semanticColors.linkHovered);

  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
*/

//Code Goes from here

import {
  BaseClientSideWebPart
} from '@microsoft/sp-webpart-base';

import{
IPropertyPaneConfiguration,
  PropertyPaneTextField,
  PropertyPaneToggle,
  PropertyPaneSlider,
  IPropertyPaneDropdownOption,
  PropertyPaneDropdown
} from '@microsoft/sp-property-pane';

import './DemoSolPowerBiWebPart.module.scss';

import { PowerBiWorkspace, PowerBiReport } from './../../models/PowerBiModels';
import { PowerBiService } from './../../services/PowerBiService';
import { PowerBiEmbeddingService } from './../../services/PowerBiEmbeddingService';

export interface IPowerBiReportLoaderWebPartProps {
  workspaceId: string;
  reportId: string;
}

export default class PowerBiReportLoaderWebPart extends BaseClientSideWebPart<IPowerBiReportLoaderWebPartProps> {

  private workspaceOptions: IPropertyPaneDropdownOption[];
  private workspacesFetched: boolean = false;

  private fetchWorkspaceOptions(): Promise<IPropertyPaneDropdownOption[]> {
    return PowerBiService.GetWorkspaces(this.context.serviceScope).then((workspaces: PowerBiWorkspace[]) => {
      var options: Array<IPropertyPaneDropdownOption> = new Array<IPropertyPaneDropdownOption>();
      workspaces.map((workspace: PowerBiWorkspace) => {
        options.push({ key: workspace.id, text: workspace.name });
      });
      return options;
    });
  }

  private reportOptions: IPropertyPaneDropdownOption[];
  private reportsFetched: boolean = false;

  private fetchReportOptions(): Promise<IPropertyPaneDropdownOption[]> {
    return PowerBiService.GetReports(this.context.serviceScope, this.properties.workspaceId).then((workspaces: PowerBiWorkspace[]) => {
      var options: Array<IPropertyPaneDropdownOption> = new Array<IPropertyPaneDropdownOption>();
      workspaces.map((report: PowerBiReport) => {
        options.push({ key: report.id, text: report.name });
      });
      return options;
    });
  }


  public render(): void {

    if (this.properties.workspaceId === "") {
      this.domElement.innerHTML = "<div class='message-container'>Select a workspace from the web part property pane</div>";
    }
    else {
      if (this.properties.reportId === "") {
        this.domElement.innerHTML = "<div class='message-container'>Select a report from the web part property pane</div>";
      }
      else {

        // here we go
        this.context.statusRenderer.displayLoadingIndicator(this.domElement, 'Calling Power BI Service API to get report info');

        PowerBiService.GetReport(this.context.serviceScope, this.properties.workspaceId, this.properties.reportId).then(

          (report: PowerBiReport) => {
            this.context.statusRenderer.clearLoadingIndicator(this.domElement);
            //this.domElement.innerHTML = "<div id='embed-container' ></div>";
            this.domElement.style.height = "480px";

            PowerBiEmbeddingService.embedReport(report, this.domElement);

          });
      }
    }
  }


  protected onPropertyPaneConfigurationStart(): void {

    console.log("onPropertyPaneConfigurationStart 1");

    if (this.workspacesFetched && this.reportsFetched) {
      console.log("onPropertyPaneConfigurationStart 2");
      return;
    }

    if (this.workspacesFetched && !this.reportsFetched) {
      console.log("onPropertyPaneConfigurationStart 3");
      this.context.statusRenderer.displayLoadingIndicator(this.domElement, 'Calling Power BI Service API to get reports');
      this.fetchReportOptions().then((options: IPropertyPaneDropdownOption[]) => {
        console.log("onPropertyPaneConfigurationStart 4");
        this.reportOptions = options;
        this.reportsFetched = true;
        this.context.propertyPane.refresh();
        this.context.statusRenderer.clearLoadingIndicator(this.domElement);
        this.render();
      });
      return;
    }

    console.log("onPropertyPaneConfigurationStart 5");
    this.context.statusRenderer.displayLoadingIndicator(this.domElement, 'Calling Power BI Service API to get workspaces');

    console.log("onPropertyPaneConfigurationStart 6");
    this.fetchWorkspaceOptions().then((options: IPropertyPaneDropdownOption[]) => {
      console.log("onPropertyPaneConfigurationStart 7");
      this.workspaceOptions = options;
      this.workspacesFetched = true;
      this.context.propertyPane.refresh();
      this.context.statusRenderer.clearLoadingIndicator(this.domElement);
      this.render();
    });

  }

  protected onPropertyPaneFieldChanged(propertyPath: string, oldValue: any, newValue: any): void {
    super.onPropertyPaneFieldChanged(propertyPath, oldValue, newValue);

    if (propertyPath === 'workspaceId' && newValue) {
      console.log("Workspace ID updated: " + newValue);
      // reset report settings
      this.properties.reportId = "";
      this.reportOptions = [];
      this.reportsFetched = false;
      // refresh the item selector control by repainting the property pane
      this.context.propertyPane.refresh();
      // communicate loading items
      this.context.statusRenderer.displayLoadingIndicator(this.domElement, 'Calling Power BI Service API to get reports');
      this.fetchReportOptions().then((options: IPropertyPaneDropdownOption[]) => {
        console.log("report options fetched");
        console.log(options);
        this.reportOptions = options;
        this.reportsFetched = true;
        this.context.propertyPane.refresh();
        this.context.statusRenderer.clearLoadingIndicator(this.domElement);
        this.render();
      });
    }

    if (propertyPath === 'reportId' && newValue) {
      this.render();
    }
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {

    return {
      pages: [{
        header: { description: "A CPT Demo Web Part" },
        groups: [{
          groupName: "Power BI Configuration",
          groupFields: [
            PropertyPaneDropdown(
              "workspaceId", {
                label: "Select a Workspace",
                options: this.workspaceOptions,
                disabled: !this.workspacesFetched
              }),
            PropertyPaneDropdown(
              "reportId", {
                label: "Select a Report",
                options: this.reportOptions,
                disabled: !this.reportsFetched
              })
          ]
        }
        ]
      }
      ]
    };
  }
}
